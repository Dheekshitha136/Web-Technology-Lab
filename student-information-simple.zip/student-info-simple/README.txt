STUDENT INFORMATION WEB SERVER — SIMPLE VERSION

TO RUN:
1. Install Node.js if it is not already installed.
2. Open this folder in VS Code.
3. Choose Terminal > New Terminal.
4. Type: node server.js
5. Open Chrome and go to: http://localhost:3000
6. Keep the terminal open while using the webpage. Press Ctrl+C to stop.

Only two things to remember: run `node server.js`, then open `http://localhost:3000`.

MODULES USED:
- http: creates the web server and responds to browser requests.
- fs: reads and saves student records in data/students.json.
- url: reads the webpage path and search query.

The webpage lets you view, search, and add student records. Example records are fictional.
