const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const dataFile = path.join(__dirname, 'data', 'students.json');
if (!fs.existsSync(dataFile)) {
  fs.mkdirSync(path.dirname(dataFile), { recursive: true });
  fs.writeFileSync(dataFile, JSON.stringify([
    { id: 1, name: 'Ananya Kumar', department: 'Information Technology', year: 'III', email: 'ananya@example.com' },
    { id: 2, name: 'Rahul Sharma', department: 'Computer Science', year: 'II', email: 'rahul@example.com' },
    { id: 3, name: 'Meera S', department: 'Electronics', year: 'IV', email: 'meera@example.com' }
  ], null, 2));
}

const page = `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Student Information</title><style>
*{box-sizing:border-box}body{margin:0;font-family:Arial,sans-serif;background:#f4f6fb;color:#20253a}.top{background:#5146d8;color:white;padding:24px 7%;font-size:25px;font-weight:bold}.wrap{max-width:1000px;margin:30px auto;padding:0 18px}.sub{color:#667085;margin-top:7px}.stats{display:flex;gap:14px;margin:22px 0}.stat,.panel{background:white;border-radius:12px;padding:20px;box-shadow:0 3px 14px #18204a0b}.stat{flex:1}.num{font-size:27px;font-weight:bold;color:#5146d8;margin-top:8px}.panel h2{margin-top:0}input,select,button{padding:11px;border:1px solid #d9dce7;border-radius:7px;font-size:14px}input,select{margin:4px 5px 10px 0}button{background:#5146d8;color:white;border:0;cursor:pointer}table{width:100%;border-collapse:collapse;margin-top:12px}th,td{text-align:left;padding:13px 10px;border-bottom:1px solid #edf0f5;font-size:14px}th{color:#667085;background:#fafaff}.formrow{display:flex;flex-wrap:wrap;gap:5px}#message{color:#18835a;margin-top:8px}@media(max-width:650px){.stats{flex-direction:column}table{font-size:12px}th,td{padding:9px 5px}}
</style></head><body><div class="top">Student Information System</div><main class="wrap"><h1>Student Dashboard</h1><div class="sub">A simple student information web server built with Node.js</div><div class="stats"><div class="stat">Total Students<div class="num" id="total">0</div></div><div class="stat">Departments<div class="num" id="depts">0</div></div></div><section class="panel"><h2>Student Records</h2><input id="search" placeholder="Search by student name" oninput="loadStudents()"><table><thead><tr><th>ID</th><th>Name</th><th>Department</th><th>Year</th><th>Email</th></tr></thead><tbody id="rows"></tbody></table></section><br><section class="panel"><h2>Add a Student</h2><form id="form"><div class="formrow"><input name="name" placeholder="Student name" required><input name="department" placeholder="Department" required><input name="year" placeholder="Year (e.g. III)" required><input name="email" type="email" placeholder="Email" required><button>Add Student</button></div></form><div id="message"></div></section><p class="sub">Demo project: sample records are fictional.</p></main><script>
async function loadStudents(){const q=encodeURIComponent(document.getElementById('search').value);const r=await fetch('/students?search='+q);const data=await r.json();document.getElementById('total').textContent=data.length;document.getElementById('depts').textContent=new Set(data.map(s=>s.department)).size;document.getElementById('rows').innerHTML=data.map(s=>'<tr><td>'+s.id+'</td><td>'+s.name+'</td><td>'+s.department+'</td><td>'+s.year+'</td><td>'+s.email+'</td></tr>').join('')||'<tr><td colspan="5">No students found</td></tr>'}
document.getElementById('form').addEventListener('submit',async e=>{e.preventDefault();const student=Object.fromEntries(new FormData(e.target));const r=await fetch('/students',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(student)});const out=await r.json();document.getElementById('message').textContent=out.message;e.target.reset();loadStudents()});loadStudents();
</script></body></html>`;

const server = http.createServer((req, res) => {
  const parsed = new URL(req.url, 'http://localhost:3000'); // url module
  if (parsed.pathname === '/' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); res.end(page); return;
  }
  if (parsed.pathname === '/students' && req.method === 'GET') {
    const students = JSON.parse(fs.readFileSync(dataFile, 'utf8')); // fs module
    const search = (parsed.searchParams.get('search') || '').toLowerCase();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(students.filter(s => s.name.toLowerCase().includes(search)))); return;
  }
  if (parsed.pathname === '/students' && req.method === 'POST') {
    let body = ''; req.on('data', chunk => body += chunk);
    req.on('end', () => {
      try {
        const newStudent = JSON.parse(body); const students = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
        newStudent.id = students.length ? Math.max(...students.map(s => s.id)) + 1 : 1;
        students.push(newStudent); fs.writeFileSync(dataFile, JSON.stringify(students, null, 2));
        res.writeHead(201, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: 'Student added successfully!' }));
      } catch { res.writeHead(400); res.end(JSON.stringify({ message: 'Could not add student.' })); }
    }); return;
  }
  res.writeHead(404, { 'Content-Type': 'text/plain' }); res.end('Page not found');
});
server.listen(3000, () => console.log('Server running at http://localhost:3000'));
