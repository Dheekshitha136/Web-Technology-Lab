import dotenv from "dotenv";

// Importing this file (first, in index.mjs) loads .env into process.env
dotenv.config();
