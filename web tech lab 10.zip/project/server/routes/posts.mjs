import express from "express";
import { ObjectId } from "mongodb";
import db from "../db/conn.mjs";

const router = express.Router();
const posts = db.collection("posts");

export const MOODS = ["curious", "fired-up", "calm", "proud", "stuck"];

const isId = (id) => /^[a-f\d]{24}$/i.test(id);
const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);

// ~200 words per minute, never less than 1
const readingMinutes = (body) =>
  Math.max(1, Math.round(body.split(/\s+/).filter(Boolean).length / 200));

function validate(input, { partial = false } = {}) {
  const errors = [];
  const clean = {};

  if (!partial || "title" in input) {
    const title = String(input.title ?? "").trim();
    if (!title) errors.push("Add a title.");
    else if (title.length > 120) errors.push("Keep the title under 120 characters.");
    clean.title = title;
  }

  if (!partial || "body" in input) {
    const body = String(input.body ?? "").trim();
    if (!body) errors.push("Write something in the note body.");
    clean.body = body;
    if (body) clean.readingMinutes = readingMinutes(body);
  }

  if (!partial || "mood" in input) {
    const mood = input.mood ?? "calm";
    if (!MOODS.includes(mood)) errors.push(`Mood must be one of: ${MOODS.join(", ")}.`);
    clean.mood = mood;
  }

  if ("pinned" in input) clean.pinned = Boolean(input.pinned);
  else if (!partial) clean.pinned = false;

  return { clean, errors };
}

// READ all  ->  GET /api/posts?mood=calm&q=rain
router.get("/", wrap(async (req, res) => {
  const { mood, q } = req.query;
  const filter = {};
  if (MOODS.includes(mood)) filter.mood = mood;
  if (typeof q === "string" && q.trim()) {
    const rx = new RegExp(escapeRegex(q.trim()), "i");
    filter.$or = [{ title: rx }, { body: rx }];
  }
  const results = await posts.find(filter).sort({ pinned: -1, createdAt: -1 }).toArray();
  res.json(results);
}));

// READ one  ->  GET /api/posts/:id
router.get("/:id", wrap(async (req, res) => {
  if (!isId(req.params.id)) return res.status(400).json({ error: "That note id is not valid." });
  const post = await posts.findOne({ _id: new ObjectId(req.params.id) });
  if (!post) return res.status(404).json({ error: "That note doesn't exist (it may have been deleted)." });
  res.json(post);
}));

// CREATE  ->  POST /api/posts
router.post("/", wrap(async (req, res) => {
  const { clean, errors } = validate(req.body ?? {});
  if (errors.length) return res.status(400).json({ errors });

  const now = new Date();
  const doc = { ...clean, createdAt: now, updatedAt: now };
  const { insertedId } = await posts.insertOne(doc);
  res.status(201).json({ _id: insertedId, ...doc });
}));

// UPDATE  ->  PATCH /api/posts/:id   (send only the fields that changed)
router.patch("/:id", wrap(async (req, res) => {
  if (!isId(req.params.id)) return res.status(400).json({ error: "That note id is not valid." });
  const { clean, errors } = validate(req.body ?? {}, { partial: true });
  if (errors.length) return res.status(400).json({ errors });
  if (!Object.keys(clean).length) return res.status(400).json({ error: "Nothing to update." });

  const _id = new ObjectId(req.params.id);
  const { matchedCount } = await posts.updateOne({ _id }, { $set: { ...clean, updatedAt: new Date() } });
  if (!matchedCount) return res.status(404).json({ error: "That note doesn't exist." });
  res.json(await posts.findOne({ _id }));
}));

// DELETE  ->  DELETE /api/posts/:id
router.delete("/:id", wrap(async (req, res) => {
  if (!isId(req.params.id)) return res.status(400).json({ error: "That note id is not valid." });
  const { deletedCount } = await posts.deleteOne({ _id: new ObjectId(req.params.id) });
  if (!deletedCount) return res.status(404).json({ error: "That note doesn't exist." });
  res.status(204).end();
}));

export default router;
