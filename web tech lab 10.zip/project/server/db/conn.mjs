import { MongoClient } from "mongodb";
import "../loadEnvironment.mjs";

const uri = process.env.ATLAS_URI;
if (!uri) {
  throw new Error("ATLAS_URI is missing. Copy .env.example to .env and add your Atlas connection string.");
}

const client = new MongoClient(uri);

try {
  await client.connect();
  console.log("Connected to MongoDB Atlas");
} catch (err) {
  console.error("Could not connect to MongoDB Atlas:", err.message);
  process.exit(1);
}

const db = client.db(process.env.DB_NAME || "field_notes");

export default db;
