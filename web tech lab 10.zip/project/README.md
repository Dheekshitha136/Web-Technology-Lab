# Field Notes: a pinboard blog built with React, Express and MongoDB

Each post is an index card ("note") with a mood colour, an optional pin and an
auto-calculated reading time. The editor is the ruled card itself.

    React (Vite)  --fetch()-->  Express REST API  -->  MongoDB Atlas

## Setup

### 1. Server
    cd server
    npm install
    cp .env.example .env      # then paste your Atlas connection string into ATLAS_URI
    npm run dev               # http://localhost:5050

Atlas checklist: create a free cluster, add a database user, and allow your IP
under Network Access.

### 2. App
    cd app
    npm install
    npm run dev               # http://localhost:5173  (proxies /api to :5050)

## REST API

| Method | Endpoint                        | What it does                          |
|--------|---------------------------------|---------------------------------------|
| GET    | /api/posts?mood=calm&q=rain     | List posts (pinned first), filterable |
| GET    | /api/posts/:id                  | One post                              |
| POST   | /api/posts                      | Create (title, body, mood, pinned)    |
| PATCH  | /api/posts/:id                  | Update any subset of fields           |
| DELETE | /api/posts/:id                  | Delete (204)                          |

## Post document

    { _id, title, body, mood, pinned, readingMinutes, createdAt, updatedAt }
