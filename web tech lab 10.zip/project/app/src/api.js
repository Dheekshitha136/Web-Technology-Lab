// All network calls live here, using the browser's native fetch().
const BASE = import.meta.env.VITE_API_URL ?? "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (res.status === 204) return null;

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.errors?.join(" ") || data.error || "Something went wrong. Try again.");
  }
  return data;
}

export const api = {
  list(params = {}) {
    const qs = new URLSearchParams(Object.entries(params).filter(([, v]) => v)).toString();
    return request(`/posts${qs ? `?${qs}` : ""}`);
  },
  get: (id) => request(`/posts/${id}`),
  create: (post) => request("/posts", { method: "POST", body: JSON.stringify(post) }),
  update: (id, changes) => request(`/posts/${id}`, { method: "PATCH", body: JSON.stringify(changes) }),
  remove: (id) => request(`/posts/${id}`, { method: "DELETE" }),
};

export const formatDate = (iso, opts = { day: "numeric", month: "short", year: "numeric" }) =>
  new Date(iso).toLocaleDateString(undefined, opts);
