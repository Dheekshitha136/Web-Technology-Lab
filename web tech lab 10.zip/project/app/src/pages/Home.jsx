import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api.js";
import PostSummary from "../components/PostSummary.jsx";

export default function Home() {
  const [posts, setPosts] = useState(null);
  const [error, setError] = useState("");

  const load = () =>
    api.list().then(setPosts).catch((e) => setError(e.message));

  useEffect(() => { load(); }, []);

  async function togglePin(post) {
    try {
      await api.update(post._id, { pinned: !post.pinned });
      await load(); // server sorts pinned notes first
    } catch (e) {
      setError(e.message);
    }
  }

  if (error) return <div className="state"><h1>Couldn't load the board</h1><p>{error}</p><p>Check that the API is running on port 5050.</p></div>;
  if (!posts) return <div className="state"><p>Loading notes…</p></div>;

  const pinned = posts.filter((p) => p.pinned).length;

  return (
    <>
      <section className="board-head">
        <h1>The board</h1>
        <p>
          {posts.length === 0
            ? "Nothing pinned up yet."
            : `${posts.length} ${posts.length === 1 ? "note" : "notes"} on the board, ${pinned} pinned.`}
        </p>
      </section>

      {posts.length === 0 ? (
        <div className="state">
          <p>Your board is empty. Write the first note and it will show up here.</p>
          <Link to="/new" className="btn">Write a note</Link>
        </div>
      ) : (
        <div className="board">
          {posts.map((p) => (
            <PostSummary key={p._id} post={p} onTogglePin={togglePin} />
          ))}
        </div>
      )}
    </>
  );
}
