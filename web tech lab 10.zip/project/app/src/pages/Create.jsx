import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "../api.js";
import { MOODS, moodOf } from "../moods.js";

const EMPTY = { title: "", body: "", mood: "calm", pinned: false };

// One page, two jobs: /new creates a note, /edit/:id updates one.
export default function Create() {
  const { id } = useParams();
  const editing = Boolean(id);
  const navigate = useNavigate();

  const [form, setForm] = useState(EMPTY);
  const [loading, setLoading] = useState(editing);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!editing) return;
    api.get(id)
      .then(({ title, body, mood, pinned }) => setForm({ title, body, mood, pinned: !!pinned }))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, [id, editing]);

  const set = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.type === "checkbox" ? e.target.checked : e.target.value }));

  const words = form.body.trim().split(/\s+/).filter(Boolean).length;
  const minutes = Math.max(1, Math.round(words / 200));

  async function submit(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      const saved = editing ? await api.update(id, form) : await api.create(form);
      navigate(`/post/${saved._id}`);
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  }

  if (loading) return <div className="state"><p>Loading note…</p></div>;

  return (
    <form className="card card--editor" onSubmit={submit} style={{ "--mood": moodOf(form.mood).color }}>
      <h1 className="visually-hidden">{editing ? "Edit note" : "New note"}</h1>

      <fieldset className="moods">
        <legend>Mood</legend>
        {MOODS.map((m) => (
          <label key={m.key} className={form.mood === m.key ? "chip is-on" : "chip"} style={{ "--chip": m.color }}>
            <input type="radio" name="mood" value={m.key} checked={form.mood === m.key} onChange={set("mood")} />
            {m.label}
          </label>
        ))}
      </fieldset>

      <label className="visually-hidden" htmlFor="title">Title</label>
      <input
        id="title"
        className="title-input"
        placeholder="Give this note a title"
        value={form.title}
        onChange={set("title")}
        maxLength={120}
        autoFocus
      />

      <label className="visually-hidden" htmlFor="body">Note</label>
      <textarea
        id="body"
        className="ruled body-input"
        placeholder="Write on the lines…"
        value={form.body}
        onChange={set("body")}
        rows={10}
      />

      {error && <p className="error" role="alert">{error}</p>}

      <div className="editor-foot">
        <label className="check">
          <input type="checkbox" checked={form.pinned} onChange={set("pinned")} />
          Pin to the top of the board
        </label>
        <span className="count">{words} {words === 1 ? "word" : "words"}, {minutes} min read</span>
      </div>

      <div className="actions">
        <button className="btn" disabled={saving}>{saving ? "Saving…" : editing ? "Save changes" : "Publish note"}</button>
        <Link to={editing ? `/post/${id}` : "/"} className="btn btn--ghost">Cancel</Link>
      </div>
    </form>
  );
}
