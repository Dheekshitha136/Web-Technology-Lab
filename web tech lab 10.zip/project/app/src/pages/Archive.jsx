import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api, formatDate } from "../api.js";
import { MOODS, moodOf } from "../moods.js";

export default function Archive() {
  const [posts, setPosts] = useState(null);
  const [mood, setMood] = useState("");
  const [q, setQ] = useState("");
  const [error, setError] = useState("");

  // Server-side filtering: GET /api/posts?mood=...&q=... (search is debounced)
  useEffect(() => {
    const t = setTimeout(() => {
      api.list({ mood, q }).then(setPosts).catch((e) => setError(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [mood, q]);

  // Archive is chronological, so pinned status is ignored here. Group by month.
  const months = useMemo(() => {
    if (!posts) return [];
    const sorted = [...posts].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    const groups = new Map();
    for (const p of sorted) {
      const key = formatDate(p.createdAt, { month: "long", year: "numeric" });
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(p);
    }
    return [...groups];
  }, [posts]);

  return (
    <>
      <section className="board-head">
        <h1>Archive</h1>
        <p>Every note, newest first.</p>
      </section>

      <div className="filters">
        <label className="visually-hidden" htmlFor="q">Search notes</label>
        <input id="q" type="search" placeholder="Search titles and text" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="chips" role="group" aria-label="Filter by mood">
          <button className={`chip ${mood === "" ? "is-on" : ""}`} style={{ "--chip": "#22334A" }} onClick={() => setMood("")}>All</button>
          {MOODS.map((m) => (
            <button key={m.key} className={`chip ${mood === m.key ? "is-on" : ""}`} style={{ "--chip": m.color }} onClick={() => setMood(m.key)}>
              {m.label}
            </button>
          ))}
        </div>
      </div>

      {error && <p className="error" role="alert">{error}</p>}
      {!posts && !error && <div className="state"><p>Loading…</p></div>}
      {posts && months.length === 0 && (
        <div className="state"><p>No notes match. Clear the search or pick another mood.</p></div>
      )}

      {months.map(([month, items]) => (
        <section key={month} className="month">
          <h2>{month}</h2>
          <ol className="timeline">
            {items.map((p) => (
              <li key={p._id} style={{ "--mood": moodOf(p.mood).color }}>
                <time dateTime={p.createdAt}>{formatDate(p.createdAt, { day: "numeric", weekday: "short" })}</time>
                <Link to={`/post/${p._id}`}>{p.title}</Link>
                <span className="mood-tag">{moodOf(p.mood).label}</span>
              </li>
            ))}
          </ol>
        </section>
      ))}
    </>
  );
}
