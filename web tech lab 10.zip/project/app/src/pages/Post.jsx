import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api, formatDate } from "../api.js";
import { moodOf } from "../moods.js";

export default function Post() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [error, setError] = useState("");
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setPost(null);
    setError("");
    api.get(id).then(setPost).catch((e) => setError(e.message));
  }, [id]);

  async function remove() {
    setBusy(true);
    try {
      await api.remove(id);
      navigate("/");
    } catch (e) {
      setError(e.message);
      setBusy(false);
    }
  }

  if (error && !post) return <div className="state"><h1>Note not found</h1><p>{error}</p><Link to="/" className="btn">Back to the board</Link></div>;
  if (!post) return <div className="state"><p>Loading note…</p></div>;

  const mood = moodOf(post.mood);
  const edited = post.updatedAt !== post.createdAt;

  return (
    <article className="card card--full" style={{ "--mood": mood.color }}>
      <div className="card-meta">
        <span className="mood-tag">{mood.label}</span>
        <span>{formatDate(post.createdAt, { dateStyle: "long" })}</span>
        <span>{post.readingMinutes} min read</span>
        {edited && <span>Edited {formatDate(post.updatedAt)}</span>}
      </div>

      <h1>{post.title}</h1>

      <div className="ruled prose">
        {post.body.split(/\n{2,}/).map((para, i) => <p key={i}>{para}</p>)}
      </div>

      {error && <p className="error" role="alert">{error}</p>}

      <div className="actions">
        <Link to={`/edit/${post._id}`} className="btn">Edit note</Link>
        {confirming ? (
          <span className="confirm" role="group" aria-label="Confirm delete">
            <span>Delete this note for good?</span>
            <button className="btn btn--danger" onClick={remove} disabled={busy}>{busy ? "Deleting…" : "Yes, delete"}</button>
            <button className="btn btn--ghost" onClick={() => setConfirming(false)}>Keep it</button>
          </span>
        ) : (
          <button className="btn btn--ghost" onClick={() => setConfirming(true)}>Delete</button>
        )}
        <Link to="/" className="btn btn--ghost">Back to the board</Link>
      </div>
    </article>
  );
}
