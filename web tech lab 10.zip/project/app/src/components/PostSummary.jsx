import { Link } from "react-router-dom";
import { moodOf } from "../moods.js";
import { formatDate } from "../api.js";

// Stable "hand-pinned" tilt derived from the id, so cards don't jump on re-render.
function tilt(id) {
  let h = 0;
  for (const ch of String(id)) h = (h * 31 + ch.charCodeAt(0)) % 997;
  return ((h % 5) - 2) * 0.45;
}

export default function PostSummary({ post, onTogglePin }) {
  const mood = moodOf(post.mood);
  const excerpt = post.body.length > 170 ? `${post.body.slice(0, 170).trimEnd()}…` : post.body;

  return (
    <article
      className="card card--summary"
      style={{ "--mood": mood.color, "--tilt": `${tilt(post._id)}deg` }}
    >
      {onTogglePin && (
        <button
          type="button"
          className={`pin ${post.pinned ? "is-on" : ""}`}
          onClick={() => onTogglePin(post)}
          aria-pressed={post.pinned}
          aria-label={post.pinned ? `Unpin "${post.title}"` : `Pin "${post.title}"`}
          title={post.pinned ? "Unpin" : "Pin to top"}
        />
      )}
      <Link to={`/post/${post._id}`} className="card-link">
        <div className="card-meta">
          <span className="mood-tag">{mood.label}</span>
          <span>{formatDate(post.createdAt)}</span>
        </div>
        <h2>{post.title}</h2>
        <p className="excerpt ruled">{excerpt}</p>
        <div className="card-foot">{post.readingMinutes} min read</div>
      </Link>
    </article>
  );
}
