import { NavLink, Route, Routes, Link } from "react-router-dom";
import Home from "./pages/Home.jsx";
import Create from "./pages/Create.jsx";
import Post from "./pages/Post.jsx";
import Archive from "./pages/Archive.jsx";

export default function App() {
  return (
    <>
      <header className="masthead">
        <Link to="/" className="brand">Field Notes</Link>
        <nav aria-label="Main">
          <NavLink to="/" end>Board</NavLink>
          <NavLink to="/archive">Archive</NavLink>
          <NavLink to="/new" className="nav-cta">New note</NavLink>
        </nav>
      </header>

      <main className="page">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/new" element={<Create />} />
          <Route path="/edit/:id" element={<Create />} />
          <Route path="/post/:id" element={<Post />} />
          <Route path="/archive" element={<Archive />} />
          <Route
            path="*"
            element={
              <div className="state">
                <h1>Nothing here</h1>
                <p>That page doesn't exist. <Link to="/">Go back to the board.</Link></p>
              </div>
            }
          />
        </Routes>
      </main>
    </>
  );
}
