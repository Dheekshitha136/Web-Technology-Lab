// Each note carries a mood. The mood colours the card's top edge everywhere it appears.
export const MOODS = [
  { key: "curious",  label: "Curious",  color: "#2E9CA6" },
  { key: "fired-up", label: "Fired up", color: "#E4572E" },
  { key: "calm",     label: "Calm",     color: "#6C8EDB" },
  { key: "proud",    label: "Proud",    color: "#E8A91C" },
  { key: "stuck",    label: "Stuck",    color: "#9A79D1" },
];

export const moodOf = (key) => MOODS.find((m) => m.key === key) ?? MOODS[2];
