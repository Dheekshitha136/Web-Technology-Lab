# MERN Todo App

A full MERN (MongoDB, Express, React, Node.js) stack conversion of a simple
React + Node.js todo project. This implements the algorithm and components
described in the assignment: task list state, `componentDidMount` data
fetch, `handleInputChange` / `handleSubmit`, a REST API backed by MongoDB,
and a Todo schema/model.

## Project structure

```
mern-todo-app/
├── backend/
│   ├── models/
│   │   └── Todo.js          # Mongoose schema + model
│   ├── routes/
│   │   └── todos.js         # GET / POST / PUT / DELETE endpoints
│   ├── server.js            # Express app, MongoDB connection
│   ├── package.json
│   └── .env.example
└── frontend/
    ├── public/
    │   └── index.html
    ├── src/
    │   ├── components/
    │   │   ├── TaskForm.js
    │   │   ├── TaskList.js
    │   │   └── TaskItem.js
    │   ├── App.js            # main component (state, lifecycle, handlers)
    │   ├── App.css
    │   └── index.js
    └── package.json
```

## How to run it

### 1. MongoDB
Have a MongoDB instance running, either locally (`mongod`) or a free
MongoDB Atlas cluster. Copy the connection string.

### 2. Backend
```bash
cd backend
npm install
cp .env.example .env      # then edit MONGO_URI if using Atlas
npm run dev                # starts on http://localhost:5000
```

### 3. Frontend
```bash
cd frontend
npm install
npm start                  # starts on http://localhost:3000
```

The React app calls `http://localhost:5000/api/todos` for all data, so run
the backend first.

## API endpoints

| Method | Endpoint            | Description            |
|--------|----------------------|-------------------------|
| GET    | /api/todos           | Fetch all tasks         |
| POST   | /api/todos           | Add a new task          |
| PUT    | /api/todos/:id       | Update a task           |
| DELETE | /api/todos/:id       | Delete a task           |

## Todo schema

```js
{
  task: String,       // required
  completed: Boolean, // default false
  createdAt: Date      // default Date.now
}
```

## Notes for the report

- The React side keeps `todos` and `newTodo` in component state, exactly as
  described in the algorithm.
- `componentDidMount` issues the initial `GET` request against MongoDB
  through the Express API.
- `handleInputChange` keeps `newTodo` in sync with the input field;
  `handleSubmit` guards against empty input, then `POST`s the new task and
  merges the server's response (including the MongoDB `_id`) into state.
- `toggleComplete` and `deleteTodo` were added on top of the base algorithm
  to demonstrate full CRUD against MongoDB (Update and Delete), which is
  useful to mention in the "CRUD operations" section of the report.
