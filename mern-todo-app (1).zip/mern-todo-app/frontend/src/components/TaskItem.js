import React from 'react';

const TaskItem = ({ todo, toggleComplete, deleteTodo }) => {
  return (
    <li className={`task-item ${todo.completed ? 'completed' : ''}`}>
      <label className="task-checkbox">
        <input
          type="checkbox"
          checked={todo.completed}
          onChange={() => toggleComplete(todo._id, todo.completed)}
        />
        <span className="task-text">{todo.task}</span>
      </label>
      <button className="delete-btn" onClick={() => deleteTodo(todo._id)}>
        Delete
      </button>
    </li>
  );
};

export default TaskItem;
