import React, { Component } from 'react';
import axios from 'axios';
import TaskForm from './components/TaskForm';
import TaskList from './components/TaskList';
import './App.css';

const API_URL = 'http://localhost:5000/api/todos';

class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      todos: [],
      newTodo: '',
    };

    this.handleInputChange = this.handleInputChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.toggleComplete = this.toggleComplete.bind(this);
    this.deleteTodo = this.deleteTodo.bind(this);
  }

  // Step 3: fetch existing tasks from MongoDB via the Express API
  componentDidMount() {
    axios
      .get(API_URL)
      .then((response) => {
        this.setState({ todos: response.data });
      })
      .catch((error) => {
        console.error('Error fetching todos:', error);
      });
  }

  // Step 6: update newTodo state as the user types
  handleInputChange(event) {
    this.setState({ newTodo: event.target.value });
  }

  // Steps 7-10: validate input, POST new task, update state
  handleSubmit(event) {
    event.preventDefault();

    if (this.state.newTodo.trim() === '') {
      return;
    }

    const newTask = {
      task: this.state.newTodo,
      completed: false,
    };

    axios
      .post(API_URL, newTask)
      .then((response) => {
        this.setState({
          todos: [response.data, ...this.state.todos],
          newTodo: '',
        });
      })
      .catch((error) => {
        console.error('Error adding todo:', error);
      });
  }

  // Bonus CRUD: toggle a task's completed flag
  toggleComplete(id, completed) {
    axios
      .put(`${API_URL}/${id}`, { completed: !completed })
      .then((response) => {
        this.setState({
          todos: this.state.todos.map((todo) =>
            todo._id === id ? response.data : todo
          ),
        });
      })
      .catch((error) => {
        console.error('Error updating todo:', error);
      });
  }

  // Bonus CRUD: delete a task
  deleteTodo(id) {
    axios
      .delete(`${API_URL}/${id}`)
      .then(() => {
        this.setState({
          todos: this.state.todos.filter((todo) => todo._id !== id),
        });
      })
      .catch((error) => {
        console.error('Error deleting todo:', error);
      });
  }

  render() {
    return (
      <div className="App">
        <div className="container">
          <h1>MERN Todo App</h1>
          <p className="subtitle">MongoDB, Express, React and Node.js</p>
          <TaskForm
            newTodo={this.state.newTodo}
            handleInputChange={this.handleInputChange}
            handleSubmit={this.handleSubmit}
          />
          <TaskList
            todos={this.state.todos}
            toggleComplete={this.toggleComplete}
            deleteTodo={this.deleteTodo}
          />
        </div>
      </div>
    );
  }
}

export default App;
